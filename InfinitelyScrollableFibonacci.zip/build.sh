#!/bin/bash

./gradlew assembleRelease
